def times2(a_value):

    """ Return twice a_value  """
    the_result = a_value + a_value
    return the_result 
a = 4

def magic7(an_integer):
    """ return 7 everytime it's called"""
    the_result = 7
    return the_result

def all_ops_pt1(int1, int2):
    """ This function takes any two integers and returns the tuple
            ( int1 + int2, int1 - int2, int1 * int2, int1 / int2, int1 // int2, int1 % int2,)"""
    the_result = (tuple(int1 + int2) (int1 - int2) (int1 * int2) (int1 / int2) (int1 // int2) (int1 % int2))
    return tuple


def magic_number(a_num):
    if a_num == 7:
        return ('true')

def add_hms(hr1, min1, sec1, hr2, min2, sec2):
    """Add two hour:minute:seconds time durations and answer the sum in standard form.
    Standard form < 60"""
    the_result = sum(add_hms(hr1, min1, sec1, hr2, min2 , sec2))
    return the_result <60
   


 
