# task 1
python_installed = True

# task 2
reviewed_builtin_functions = True

# task 3
reviewed_string_methods = True

# task 4
snakify_1_attempted = True
snakify_2_attempted = True
snakify_5_attempted = True

#  end of assignment 1
