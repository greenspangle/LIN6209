Python 3.9.7 (tags/v3.9.7:1016ef3, Aug 30 2021, 20:19:38) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> # task 1
>>> python_installed = True
>>> 
>>> # task 2
>>> reviewed_bulltin_functions = True
>>> 
>>> # task 3
>>> reviewed_string_methods = True
>>> 
>>> # task 4
>>> snakify_1_attempted = True
>>> snakify_2_attempted = True
>>> snakify_3_attempted = True
>>> 
>>> #end of assignment 1